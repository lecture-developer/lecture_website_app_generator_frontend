import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemText from "@material-ui/core/ListItemText";
import Divider from "@material-ui/core/Divider";
import RadioButtonUnchecked from "@material-ui/icons/RadioButtonUnchecked";
import AboutMenuItem from "./AboutMenuItem";
import ResourcesMenuItem from "./ResourcesMenuItem";
import FooterList from "./Footer/FooterList";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    maxWidth: 310,
    backgroundColor: theme.palette.background.paper
  },
  nested: {
    paddingLeft: theme.spacing(4)
  }
}));

export default function MenuList() {
  const classes = useStyles();
  const [open, setOpen] = React.useState(false);

  const handleClick = () => {
    setOpen(!open);
  };

  return (
    <div>
      <List
        component="nav"
        aria-labelledby="nested-list-subheader"
        className={classes.root}
      >
        <AboutMenuItem />
        <ListItem button>
          <ListItemIcon>
            <RadioButtonUnchecked />
          </ListItemIcon>
          <ListItemText primary="Publications" />
        </ListItem>
        <ResourcesMenuItem />
        <ListItem button>
          <ListItemIcon>
            <RadioButtonUnchecked />
          </ListItemIcon>
          <ListItemText primary="Courses" />
        </ListItem>
      </List>
      <Divider light />
      <FooterList />
    </div>
  );
}
