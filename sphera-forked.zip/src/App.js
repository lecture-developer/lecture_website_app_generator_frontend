import React from "react";
import ReactDOM from "react-dom";
import ResponsiveDrawer from "./components/SideMenu/ResponsiveDrawer";

function App() {
  return <ResponsiveDrawer />;
}

export default App;
